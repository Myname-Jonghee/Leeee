﻿namespace MiniProjectBuycar
{
    partial class OrderPage
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            comboBox3 = new ComboBox();
            pictureBox1 = new PictureBox();
            Orderbutton = new Button();
            UserName_label = new Label();
            button1 = new Button();
            Ordercheckbutton = new Button();
            dataGridView_user = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_user).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 40F);
            label1.Location = new Point(299, 9);
            label1.Name = "label1";
            label1.Size = new Size(494, 72);
            label1.TabIndex = 0;
            label1.Text = "KIA 자동차 주문 창";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 15F);
            label2.Location = new Point(160, 163);
            label2.Name = "label2";
            label2.Size = new Size(99, 28);
            label2.TabIndex = 1;
            label2.Text = "차량 종류";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 15F);
            label3.Location = new Point(160, 239);
            label3.Name = "label3";
            label3.Size = new Size(99, 28);
            label3.TabIndex = 2;
            label3.Text = "엔진 선택";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 15F);
            label4.Location = new Point(160, 310);
            label4.Name = "label4";
            label4.Size = new Size(99, 28);
            label4.TabIndex = 3;
            label4.Text = "색상 선택";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(299, 168);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 4;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(299, 239);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 5;
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(299, 310);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(121, 23);
            comboBox3.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(495, 95);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(529, 315);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // Orderbutton
            // 
            Orderbutton.Font = new Font("맑은 고딕", 12F);
            Orderbutton.Location = new Point(172, 365);
            Orderbutton.Name = "Orderbutton";
            Orderbutton.Size = new Size(248, 85);
            Orderbutton.TabIndex = 8;
            Orderbutton.Text = "주문 저장";
            Orderbutton.UseVisualStyleBackColor = true;
            Orderbutton.Click += Orderbutton_Click;
            // 
            // UserName_label
            // 
            UserName_label.AutoSize = true;
            UserName_label.Font = new Font("맑은 고딕", 15F);
            UserName_label.Location = new Point(0, 0);
            UserName_label.Name = "UserName_label";
            UserName_label.Size = new Size(159, 28);
            UserName_label.TabIndex = 9;
            UserName_label.Text = "UserName_label";
            // 
            // button1
            // 
            button1.Location = new Point(140, 50);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 10;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Ordercheckbutton
            // 
            Ordercheckbutton.Location = new Point(205, 543);
            Ordercheckbutton.Name = "Ordercheckbutton";
            Ordercheckbutton.Size = new Size(142, 59);
            Ordercheckbutton.TabIndex = 11;
            Ordercheckbutton.Text = "주문 정보 확인하기";
            Ordercheckbutton.UseVisualStyleBackColor = true;
            Ordercheckbutton.Click += Ordercheckbutton_Click;
            // 
            // dataGridView_user
            // 
            dataGridView_user.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView_user.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_user.Location = new Point(495, 425);
            dataGridView_user.Name = "dataGridView_user";
            dataGridView_user.Size = new Size(529, 203);
            dataGridView_user.TabIndex = 13;
            // 
            // OrderPage
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1123, 664);
            Controls.Add(dataGridView_user);
            Controls.Add(Ordercheckbutton);
            Controls.Add(button1);
            Controls.Add(UserName_label);
            Controls.Add(Orderbutton);
            Controls.Add(pictureBox1);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "OrderPage";
            Text = "Form1";
            Load += OrderPage_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_user).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private ComboBox comboBox3;
        private PictureBox pictureBox1;
        private Button Orderbutton;
        private Label UserName_label;
        private Button button1;
        private Button Ordercheckbutton;
        private DataGridView dataGridView_user;
    }
}
