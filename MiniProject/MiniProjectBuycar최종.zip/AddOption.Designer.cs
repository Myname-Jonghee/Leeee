﻿namespace MiniProjectBuycar
{
    partial class AddOption
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            comboBox1 = new ComboBox();
            textBox1 = new TextBox();
            Optionbutton = new Button();
            LastConfirmbutton = new Button();
            PriceTextBox = new TextBox();
            Cancelbutton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 18F);
            label1.Location = new Point(123, 93);
            label1.Name = "label1";
            label1.Size = new Size(214, 32);
            label1.TabIndex = 0;
            label1.Text = "옵션을 선택하세요";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(160, 149);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 1;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("맑은 고딕", 16F);
            textBox1.Location = new Point(457, 43);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(315, 290);
            textBox1.TabIndex = 2;
            // 
            // Optionbutton
            // 
            Optionbutton.Font = new Font("맑은 고딕", 15F);
            Optionbutton.Location = new Point(150, 206);
            Optionbutton.Name = "Optionbutton";
            Optionbutton.Size = new Size(142, 79);
            Optionbutton.TabIndex = 3;
            Optionbutton.Text = "옵션 저장";
            Optionbutton.UseVisualStyleBackColor = true;
            Optionbutton.Click += Optionbutton_Click_1;
            // 
            // LastConfirmbutton
            // 
            LastConfirmbutton.Location = new Point(91, 386);
            LastConfirmbutton.Name = "LastConfirmbutton";
            LastConfirmbutton.Size = new Size(143, 68);
            LastConfirmbutton.TabIndex = 4;
            LastConfirmbutton.Text = "최종 주문하기";
            LastConfirmbutton.UseVisualStyleBackColor = true;
            LastConfirmbutton.Click += LastConfirmbutton_Click;
            // 
            // PriceTextBox
            // 
            PriceTextBox.Location = new Point(457, 356);
            PriceTextBox.Multiline = true;
            PriceTextBox.Name = "PriceTextBox";
            PriceTextBox.Size = new Size(315, 69);
            PriceTextBox.TabIndex = 5;
            // 
            // Cancelbutton
            // 
            Cancelbutton.Location = new Point(269, 386);
            Cancelbutton.Name = "Cancelbutton";
            Cancelbutton.Size = new Size(143, 68);
            Cancelbutton.TabIndex = 6;
            Cancelbutton.Text = "주문 취소하기";
            Cancelbutton.UseVisualStyleBackColor = true;
            Cancelbutton.Click += Cancelbutton_Click;
            // 
            // AddOption
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(826, 485);
            Controls.Add(Cancelbutton);
            Controls.Add(PriceTextBox);
            Controls.Add(LastConfirmbutton);
            Controls.Add(Optionbutton);
            Controls.Add(textBox1);
            Controls.Add(comboBox1);
            Controls.Add(label1);
            Name = "AddOption";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ComboBox comboBox1;
        private TextBox textBox1;
        private Button Optionbutton;
        private Button LastConfirmbutton;
        private TextBox PriceTextBox;
        private Button Cancelbutton;
    }
}